# MLCG Framework - User Manual

Welcome to the **Machine Learning Coarse-Graining (MLCG) Framework**!
This pipeline is designed to extract Coarse-Grained (CG) interactions from All-Atom (AA) molecular trajectories using *Direct Boltzmann Inversion* to calculate thermodynamic priors, and Graph Neural Networks (PaiNN) in C++ (PyTorch) to fit the residual forces.

The structure is divided into three main phases, each contained in its respective folder:

1. **Preprocessing:** Dataset construction and physical prior subtraction.
2. **Training:** C++ Neural Network training.
3. **Simulation:** Coarse-Grained MD execution in ESPResSo.

---

## Phase 0: Environment Setup (Self-Contained)

To ensure maximum reproducibility, it is highly recommended to create a dedicated Python virtual environment for this framework and install the necessary packages, such as `MDAnalysis` and `numpy`.

```bash
# Enter the framework folder
cd MLCG_Framework

# Create a virtual environment named "mlcg_venv"
python3 -m venv mlcg_venv

# Activate the virtual environment
source mlcg_venv/bin/activate

# Install the necessary packages
pip install -r requirements.txt
```
*Note: remember to activate the virtual environment (`source mlcg_venv/bin/activate`) every time you open a new terminal before running the Python scripts of the framework.*

---

## Phase 1: Preprocessing and Boltzmann Inversion

All the code required to generate the training dataset is located in `preprocessing/`.

### 1.1 Configure the Topology
Before running the script, you need to define how the All-Atom atoms are mapped onto the Coarse-Grained sites and which CG sites are covalently bonded.
Open the `preprocessing/topology_config.json` file and define:
- `temperature`: The temperature (in Kelvin) of your All-Atom MD (needed to calculate $k_B T$).
- `mapping`: Lists of AA atom indices (0-indexed) or atom names that make up each CG site.
- `bonds`: Index pairs or FENE/Morse configurations for prior insertion.

This script supports flexible mapping based on JSON files. You can generate `.bin` files containing positions, forces, and torques on individual sites or centers of mass.

Execution example:
```bash
python build_cg_dataset.py \
    --trajectory ../GROMACS/ethanol.trr \
    --topology ../GROMACS/ethanol.gro \
    --config topology_config.json \
    --dbi \
    --output cg_dataset.bin
```

**Options supported by `build_cg_dataset.py`:**
- `-c`, `--topology`: Topology file (e.g., `.tpr` or `.gro`).
- `-f`, `--trajectory`: Trajectory file (e.g., `.trr` or `.xtc`).
- `-j`, `--config`: JSON file with CG topology and mapping rules (default: `topology_config.json`).
- `--dbi`: Enable global Direct Boltzmann Inversion (DBI) to extract bond force constants directly from thermal distributions.
- `-p`, `--priors`: JSON file with priors (e.g., `cg_priors.json`). If provided, the script skips the statistical calculation and applies the given priors directly to the dataset. Necessary during IBI.
- `-o`, `--output`: Output binary file name (default: `../training/cg_dataset.bin`).

#### Example of `topology_config.json`
The configuration file controls temperatures, WCA potentials, spring bonds (priors), and mapping rules (Multi-Bead, COM, ATOM, COG):

```json
{
    "temperature": 300.0,
    "wca_sigma": 0.0,
    "wca_epsilon": 0.0,
    "wca_overrides": [
        {"type_i": 2, "type_j": 2, "sigma": 0.8, "epsilon": 2.5}
    ],
    "bonds": [
        [0, 1]
    ],
    "angles": [
        {"mol_i": 0, "mol_j": 1, "mol_k": 2, "site_i": 0, "site_j": 0, "site_k": 0, "theta0": "auto", "k": "auto"}
    ],
    "mapping": {
        "mapping_method": "COM",
        "residues": {
            "ETH": {
                "CG_CH3": ["C1", "H1", "H2", "H3"],
                "CG_CH2": ["C2", "H4", "H5"],
                "CG_OH":  ["O1", "H6"]
            }
        },
        "site_types": {
            "CG_CH3": 0, "CG_CH2": 1, "CG_OH": 2
        }
    },
    "rigid_bodies": {
        "ETH": {
            "auto_align_sites": true,
            "sites": {
                "CG_CH3": {"type": 0, "relative_pos_nm": [0.0, 0.0, 0.0]},
                "CG_CH2": {"type": 1, "relative_pos_nm": [0.15, 0.0, 0.0]},
                "CG_OH":  {"type": 2, "relative_pos_nm": [0.25, 0.1, 0.0]}
            }
        }
    }
}
```

> [!IMPORTANT]
> **Rigid Bodies and Kabsch Auto-Alignment**
> If you define `"rigid_bodies"` in your topology, the script will map those molecules into ESPResSo Rigid Bodies (composed of a central particle with real mass/inertia and virtual sites).
> 
> By default (`"auto_align_sites": true`), the `build_cg_dataset.py` script computes the ideal "average" geometry of these sites by extracting all snapshots from the GROMACS trajectory and aligning them with the **Kabsch algorithm**. The resulting geometries are saved in `rigid_bodies_info.json`.
> During dataset generation (Pass 2), the script uses this exact Kabsch rotation to mathematically reconstruct the ideal rigid sites on every frame before evaluating the prior forces (WCA/DBI/Harmonic). This guarantees **strict physical consistency** with ESPResSo (which does not deform rigid bodies), preventing the ML model from learning massive, unphysical counter-forces caused by instantaneous thermal vibrations.
> 
> If you prefer to manually provide the perfect ideal coordinates (e.g. from a PDB) and don't want the script to overwrite them with the trajectory average, set `"auto_align_sites": false`. The script will exactly use the `relative_pos_nm` you typed in the JSON!

### 1.2 Choice of Thermodynamic Architecture (Priors vs ML)

The framework supports three different Coarse-Graining philosophies. The choice depends on the type of system and the desired balance between numerical stability and accuracy:

1. **Pure Classical (IBI / DBI)**: Runs MD simulations driven solely by potential tables derived from all-atom distributions (e.g., using the `02_run_ibi.sh` script provided in the tutorials). You can omit the `--model` argument in `run_cg_md.py` to launch the simulation.
   - *Pros:* Very fast, does not require GPU training.
   - *Cons:* 2-body potentials do not capture complex multi-body effects or coupled conformational changes.
2. **Tabulated Delta-Learning (IBI/DBI + ML)**: Uses perfect tabulated potentials (IBI/DBI) as a baseline, leaving the Neural Network to learn only small multi-body corrections.
   > [!WARNING]
   > **Topological Vulnerability:** This approach is numerically **highly unstable** in MD, especially in the presence of complex Rigid Bodies. IBI tables have strict edges (cutoffs). If the initial noise of the neural network pushes two atoms just outside the table's range, the extrapolation generates immense forces/torques that cause the immediate explosion of the integrator ("bond broken" errors). **The use of IBI/DBI tables combined with ML is strongly discouraged unless the ML model is perfectly trained for thousands of epochs.**
3. **CGnet Approach (Harmonic Prior + ML)**: Exclusively uses perfect harmonic springs ($V = \frac{1}{2} k (r-r_0)^2$) and analytical repulsive interactions (WCA, Morse) to preserve the basic topology. The Neural Network must learn **all** the real anharmonicity.
   > [!TIP]
   > **Recommended Approach for ML:** Analytical functions are smooth and boundless. Any thermal fluctuation or predictive error from the Neural Network will be softly contained by the spring, guaranteeing absolute topological stability to the simulation. The extra energy introduced by the neural network noise ("Noise Heating") will be safely dissipated by the Langevin thermostat. This is by far the most robust path for Delta-Learning.

#### Advanced Physics: Virtual Sites, Mass Scaling, and WCA Mixing
The framework introduces a rigid-body structure to accurately map complex molecules.
- **Mass Scaling for Virtual Sites**: The primary Center of Mass (COM) retains the true mass and inertia of the rigid body. Virtual sites have their mass and inertia artificially scaled by $10^{-5}$ to prevent them from absorbing kinetic energy from the ESPResSo Langevin thermostat, preserving exact thermodynamic temperature.
- **Lorentz-Berthelot WCA**: WCA interactions between distinct sites are blended using arithmetic mean for $\sigma_{ij} = (\sigma_i + \sigma_j)/2$ and geometric mean for $\epsilon_{ij} = \sqrt{\epsilon_i \epsilon_j}$.
- **WCA Overrides**: You can define specific LJ properties for peripheral sites (e.g. bulky bases like Guanine) using the `wca_overrides` array.

#### Advanced Physics: NVE Thermodynamic Stability and Toxvaerd Cutoff
Graph Neural Networks (GNNs) like PaiNN can introduce numerical instabilities (energy drift) during NVE simulations due to mathematical discontinuities at the edges of the cutoff radius. The framework solves this problem natively by guaranteeing $\mathcal{C}^3$ order continuity to preserve the exact $\mathcal{O}(dt^2)$ scaling of the Velocity-Verlet integrator.
- **Toxvaerd Smoothing**: Traditional envelope functions (like cosine) have been replaced by a Toxvaerd rational polynomial ($n=4$), which gently brings energy, force, and curvature to zero analytically.
- **Bias Parameterization**: You can train the model by configuring `"use_bias": false` in `tel22_training_config.json`. This removes force "steps" at their source.
- **Optional Envelope**: If you use models with active biases (`"use_bias": true`), you can enable `"apply_envelope": true` to force $\mathcal{C}^3$ decay downstream, protecting the simulation. Both parameters can be dimensionlessly modulated with `"toxvaerd_alpha": 0.1`.

#### Advanced Physics: Site-Dependent Priors
By default, Harmonic bonds, Angles, and Dihedrals act on the Centers of Mass. However, you can map them to specific Virtual Sites using the `site_i`, `site_j`, `site_k`, `site_l` parameters (0-indexed referring to the molecule's mapping definition).
When applied to Virtual Sites, the forces are geometrically exact, and the framework automatically computes the **torque** $\tau = \vec{r}_{site} \times \vec{F}_{site}$ to transfer the rotational momentum back to the main Center of Mass.

#### Priors and Boltzmann Inversion (DBI vs IBI)

The framework supports two fundamental philosophies to extract prior energies from the All-Atom trajectory: **Direct Boltzmann Inversion (DBI)** and **Iterative Boltzmann Inversion (IBI)**.

##### Details of the DBI Mathematical Architecture
When a degree of freedom is marked for pure DBI, the `build_cg_dataset.py` script executes a rigorous analytical pipeline:
1. **Extraction and Histogramming**: Geometric samples are extracted from all frames to build a density distribution $P(x)$.
2. **Thermodynamic Inversion (Jacobians)**: To achieve exact analytical probability matching and prevent geometric entropy biases, the raw histogram is divided by the phase space volume (mathematical Jacobian) before applying the inversion:
   - **Bonds:** $V(r) = -k_B T \ln[P(r)/r^2]$ (correction for the spherical shell volume element)
   - **Angles:** $V(\theta) = -k_B T \ln[P(\theta)/\sin(\theta)]$ (correction for the solid angle volume)
   - **Dihedrals:** $V(\phi) = -k_B T \ln[P(\phi)]$ (no correction needed)
3. **Smoothing**: To prevent force interpolation from suffering from noise or spikes derived from bins with few samples (especially at the tails), the potential is regularized by applying a Gaussian kernel (`sigma=2.0`).
4. **Force Calculation**: Performed analytically as the numerical gradient of the smoothed potential: $F = -dV/dx$.
5. **Endpoint Extrapolation**: To ensure absolute stability during Molecular Dynamics in ESPResSo and prevent the engine from crashing if a molecule explores a region outside the sampling by thermal fluctuation (e.g., a highly stretched bond), the tails of the tabulated potential are *extrapolated* by extending the force constantly. This gives the bond a safe "hard wall" asymptotic behavior outside the sampled region.
6. **Table Export**: The resulting potential is exported as a tabulated numerical file `x V F` in `dbi_tables/`, ready for ESPResSo's native Spline interpolation.

**1. Analytical Functions (DBI, FENE, Morse, Angles, Dihedrals)**
If you include the `"bonds"` array as index lists (e.g., `[[0, 1]]`), the preprocessing script will perform basic statistics (classical DBI) to derive the harmonic constant $k$ and the equilibrium distance $r_0$.
Alternatively, you can disable automatic inference and explicitly define much more complex analytical parameters for various degrees of freedom. You can use:
- **Harmonic Bond** (`"type": "harmonic"`): the classic Hooke's spring, calculated statistically based on mean/variance (defaulting to `"r0": "auto"`, `"k": "auto"`). Extremely fast.
- **Direct Boltzmann Inversion** (`"type": "dbi"`): extracts the true thermodynamic potential by inverting the histograms (useful for non-harmonic or very asymmetric distributions/geometries). This technique saves a `.tab` file and uses force extrapolation. Also supported as a global `--dbi` terminal flag.
- **FENE Bond** (`"type": "fene"`): very useful for polymer chains where monomers must not drift beyond a certain $R_{max}$.
- **Morse Bond** (`"type": "morse"`): essential for non-linear bonds that must be able to break (like tetrad stacking or hydrogen bonds).
- **Harmonic Angles** (in the `"angles"` array): to stabilize the angle between three sites.
- **Dihedrals** (in the `"dihedrals"` array): to stabilize the torsional conformation between four sites.
This parametric approach is ultra-fast to evaluate but relies on ideal closed equations.

**2. Aggregated Statistics (Typed Topology)**
If you want multiple bonds (or angles, or dihedrals) to share the **exact same statistics**, you can group them by assigning a `"name"` attribute.
- *Without name (Bond-by-Bond)*: Each bond receives a $k, r_0$ or an IBI curve calculated exclusively using the frames of its specific atomic pair. Great for unique and exact geometries (e.g. G-Quadruplexes).
- *With name (Aggregated)*: All bonds with the same `"name"` merge their trajectories into a single large data pool. The framework will extract a global mean/variance (for "auto" springs) or a global IBI curve. Perfect for transferable models or solvents (e.g. assigning `"name": "water_OH"` to all water OH bonds).

```json
"bonds": [
    {"mol_i": 0, "mol_j": 1, "type": "ibi", "name": "PO_bond"},
    {"mol_i": 1, "mol_j": 2, "type": "ibi", "name": "PO_bond"}
]
```

**2. Iterative Boltzmann Inversion (IBI) [Exact Tabulated Curves]**
If your system is highly anharmonic or suffers from cross-interferences (e.g., steric repulsion modifies bond distances), the harmonic approximation of DBI is not sufficient. In this case, you can use the powerful integrated IBI pipeline with the real ESPResSo engine:
- Use the script in the `ibi/` folder to mathematically extract the exact potentials. The `run_ibi_loop.py` script natively reads the `_dataset.bin` file and performs **real Molecular Dynamics simulations in ESPResSo**, calculating the Kullback-Leibler divergence and correcting the curves (splines) iteratively via the Henderson equation until the simulated distribution perfectly matches the All-Atom target.
- The user has total control over the inversion types via the command line. For example, you can request IBI only for bonds, leaving DBI (more stable and efficient) for angles and dihedrals:
```bash
uv run ibi/run_ibi_loop.py \
    --dataset preprocessing/tel22_dataset.bin \
    --priors preprocessing/cg_priors.json \
    --iterations 5
```
- Once convergence is achieved, the optimal curves are saved as `.dat` files.
- Next, use `build_cg_dataset.py` again by passing the `--priors` flag to create the final dataset. This way the script will know not to recalculate the statistical priors, but will directly read the exact IBI tables and subtract them to extract the true residuals:
```bash
uv run preprocessing/build_cg_dataset.py \
    --topology md.gro \
    --trajectory md_whole.trr \
    --config topology_config.json \
    --priors cg_priors.json \
    --output dataset_ibi.bin
```
- To simulate, in your automatically updated `cg_priors.json` file, the setting will be converted to `"type": "tabulated"`, indicating the path to the generated spline:
```json
{
    "mol_i": 0, "mol_j": 1,
    "type": "tabulated",
    "file": "ibi_priors/bond_ibi_spline_0.dat",
    "min": 0.01, "max": 3.0
}
```
ESPResSo will read the numerical table (both for `TabulatedDistance` bonds, `TabulatedAngle` angles, and dihedrals) injecting the perfect IBI potential. This choice guarantees native backward compatibility and allows freely mixing DBI springs and IBI tables for different degrees of freedom!

### Practical Guide to the IBI Workflow (The Three Scripts)
The architecture logically separates the statistics extraction from the force subtraction. In the tutorials (e.g., `tel22_IBI`), you will find this workflow divided into 3 scripts:

1. **`01_build_dataset.sh` (Statistics Extraction):**
   Runs `build_cg_dataset.py` on the topology that contains the priors with `"type": "ibi"`. At this stage, the script does *not* subtract the IBI forces from the target forces (because the tables don't exist yet!). It only saves a `tel22_dataset.bin` file containing the fragment distributions and the mapped original atomistic forces.
2. **`02_run_ibi.sh` (Table Generation):**
   Reads the intermediate dataset and executes the IBI loop. It uses the target distribution to compute the DBI (iteration 0) and then iteratively launches ESPResSo to correct the potential. Upon convergence, it exports the optimal `.dat` potentials to the `ibi_priors/` folder and updates `cg_priors.json` changing their type to `"tabulated"`.
3. **`03_subtract_ibi.sh` (Force Subtraction):**
   Reruns `build_cg_dataset.py`, but this time passing the `--priors cg_priors.json` flag generated by the previous step. In this way, the framework skips the statistical inference, sees the bonds as `"tabulated"`, loads the definitive `.dat` tables, and performs the interpolation to rigorously subtract the exact force (IBI) from the residual forces of the dataset. The final output `tel22_dataset_ibi.bin` is ready to train the Machine Learning model!

> [!WARNING]
> **IBI Tables Extrapolation (SOTA) and Thermodynamic Consistency**
> The `.dat` tables produced by IBI cover *exclusively* the range of distances sampled during the simulation (e.g., from $0.1$ to $3.0$ nm).
> If during the hybrid ML+IBI training the neural network produces initial small fluctuations pushing two atoms outside the grid, ESPResSo will crash fatally with a `bond broken` error.
> 
> The State Of The Art solution (inspired by advanced tools like VOTCA) consists of **mathematically extrapolating the tails** of the `.dat` files before Molecular Dynamics, extending the grid down to $r=0$ for the repulsive core and to large distances for the attractive tail.
>
> **The Mathematical Engine Under the Hood:**
> To guarantee perfect numerical stability in ESPResSo (which uses quadratic splines for forces and cubic splines for potentials), the MLCG framework employs a **linear force extrapolation** (which corresponds to the exact analytical integration of a **quadratic potential**). 
> - Unlike quadratic force extrapolation (which generates extremely steep walls and massive force outliers), the linear force grows much more gently and remains physically manageable as it approaches $r=0$.
> - The slope of the line (gradient) is empirically inferred from the last 2 valid points of the IBI table, ensuring **$C^1$ continuity for the potential and $C^0$ continuity for the force**, without sudden jumps ("kinks").
> - If statistical noise were to invert the slope, the framework automatically intervenes by injecting a safe minimum slope to ensure the wall always remains repulsive!
>
> All this sophisticated analytical integration occurs 100% invisibly and consistently across all three steps of the framework:
> 1. In `build_cg_dataset.py` (during pure DBI).
> 2. In `run_ibi_loop.py` (during the Iterative MD cycles).
> 3. In the auxiliary script `extrapolate_ibi_tables.py` (when used for the final IBI tables).

> [!TIP]
> **Equilibrium Distance Auto-calculation (`r0`)**
> For explicit bonds (FENE, Morse, etc.), if you omit the numerical parameter and set `"r0": "auto"`, the script will automatically extract the exact mean distance for that pair of atoms directly from the molecular trajectory! This prevents thermodynamic explosions and elegantly resolves scale mismatches between all-atom and coarse-grained representations.

> [!NOTE]
> **Morse Potential and Force Capping**
> In ESPResSo, explicit Morse bonds are injected under the hood as `TabulatedDistance` (extended beyond the box size). The framework automatically applies a **Force Capping** (hard limit) to prevent integration explosions caused by the exponentially steep repulsive wall when monomers get too close, ensuring a perfect balance between bond breakability and thermodynamic stability.

Examples of explicit definition:
```json
"bonds": [
    {
        "mol_i": 0, "mol_j": 1,
        "site_i": 2, "site_j": 0,
        "type": "fene",
        "k": 1000.0,
        "r0": "auto",
        "r_max": 0.3
    },
    {
        "mol_i": 2, "mol_j": 3,
        "type": "morse",
        "D": 20.0,
        "a": 3.0,
        "r0": "auto"
    }
]
```

The script will calculate the resulting forces (and their related **torques**) and subtract them from the target values before saving the binary dataset, exporting the exact parameters to the `cg_priors.json` file.
It will also analytically subtract these harmonic/FENE/Morse forces (and WCA) from the mapped CG forces, generating the residual dataset `cg_dataset.bin` in `training/`.
Finally, it will calculate the masses and inertia tensors for the CG sites/molecules and save them in `rigid_bodies_info.json`.

---

## Phase 2: Neural Network Training (C++)

Once the `cg_dataset.bin` dataset has been generated, the training on the *residuals* takes place entirely in C++.

### 2.1 Compilation
Make sure you have downloaded LibTorch and compiled the binary:
```bash
cd training
mkdir build && cd build
cmake -DCMAKE_PREFIX_PATH=/path/to/libtorch ..
make -j4
```

### 2.2 Configure Network Parameters
In the `training/` folder you will find the `cg_model_config.json` file. This file acts as the **control hub** for the network: before starting the training, you can modify parameters such as `hidden_channels`, `n_layers`, `cutoff`, `learning_rate`, and `epochs` here. The C++ code will read this file at runtime without any need to recompile!

> [!TIP]
> **Toxvaerd C4 Smoothing and Verlet Stability (The Bias vs Envelope Trade-off)**
> Graph Neural Networks equipped with *bias* parameters generate discontinuous jumps in force derivatives at the cutoff radius, destroying the quadratic scalability of the Verlet integrator. The framework solves this problem by using the continuous and mathematically rigorous **Toxvaerd C4** cutoff. There are two configurable approaches in `cg_model_config.json`:
> 
> 1. **Rigorous Approach (Recommended / Default):** `"use_bias": false` and `"apply_envelope": false`. By eradicating the bias parameters, the network's signal decays to zero smoothly and naturally following the RBF filters. This guarantees perfect theoretical scaling ($\approx 1.99$). However, without biases, the network has fewer free parameters and struggles slightly more to fit short-range energies.
> 2. **Thermodynamic Approach (Lower Absolute Error):** `"use_bias": true` and `"apply_envelope": true`. The network retains its biases (higher expressive power and significantly lower absolute error), but the forces are "forcibly" zeroed out at the cutoff by an external envelope function. Since the network is trained with the active envelope, it learns to compensate for this damping. The theoretical scaling is slightly more nervous ($\approx 1.89$), but absolute energy fluctuations are much smaller.

> [!TIP]
> **Lipschitz Regularization**
> In the `.json` file you can add or modify the `"lipschitz_lambda": 0.001` parameter. This introduces an L2 penalty on the force magnitude during training (inspired by CGnet). By enabling it, the model learns to predict smoother energy surfaces, preventing massive gradients and explosions during ESPResSo simulations. If set to `0.0`, the additional overhead is completely bypassed ensuring absolute backward compatibility.

### 2.3 Running the Training
Start the training. By default, the program will look for `cg_dataset.bin`, `best_cg_model.pt` (for saving), and `cg_model_config.json` (for configuration).
```bash
cd training
./train_painn
```
*Note: You can pass custom paths via command-line arguments:*
`./train_painn <dataset.bin> <output_model.pt> <config.json>`

The training will save the compiled PyTorch JIT model optimized for ESPResSo.

---

#### Using the Morse Potential for Stacking Interactions (TEL22 Example)
Graph Neural Networks sometimes struggle to natively model non-linear and "fragile" long-range forces like Guanine tetrad stacking or intra-chain Van der Waals forces, especially with limited training data. An elegant and fast way to solve this is to introduce an explicit **Morse Potential** as a prior.

The Morse potential perfectly models the energetic "well" of biological stacking:
- It provides deep stability at equilibrium (regulated by the parameter `D`, well depth).
- It allows the interaction to smoothly "break" at larger distances (regulated by the parameter `a` or $\alpha$, well width), unlike harmonic bonds which would generate infinite forces and physically prevent phenomena like thermal melting or unfolding.

**Use Case (TEL22 Tutorial):**
In the case of G-Quadruplexes (TEL22), planar stacking between guanines is essential for structural compactness. Rather than forcing the Machine Learning Model to learn this complex force entirely from scratch, we explicitly inject "scaffold" Morse bonds between stacked guanines:
```json
{
    "mol_i": 2, "mol_j": 8,
    "type": "morse",
    "D": 50.0,
    "a": 3.0,
    "r0": "auto"
}
```
In this setup:
- `D` at `50.0` kJ/mol ensures the structure remains stably folded at physiological temperatures (300K). Lower values (e.g., `20.0`) would facilitate visible thermal unfolding.
- `"r0": "auto"` allows the framework to read the exact stacking distance directly from the atomistic trajectory (preventing thermodynamic explosions caused by a manually entered `r0` that misaligns with CG dimensions).
- ESPResSo will automatically apply "Force Capping" on these tabulated bonds to prevent integration explosions if monomers suffer severe thermal collisions at very short distances.

## Phase 3: Integration and Simulation in ESPResSo

The final phase is the utilization of the model and priors for MD production. To do this, you must first install the PaiNN C++ plugin within the ESPResSo source code.

### 3.1 Installing the Plugin in ESPResSo
In the `simulation/espresso_plugin/` folder you will find the 3 files needed for integration (and a symlink to the architecture file).
Copy these files into the ESPResSo source code:

```bash
# Replace "/path/to/espresso" with your ESPResSo source directory
cp simulation/espresso_plugin/PaiNN_Architecture.hpp /path/to/espresso/src/core/nonbonded_interactions/
cp simulation/espresso_plugin/PaiNN_ML_Potential.cpp /path/to/espresso/src/core/nonbonded_interactions/
cp simulation/espresso_plugin/PaiNN_ML_Potential.hpp /path/to/espresso/src/core/nonbonded_interactions/
cp simulation/espresso_plugin/painn.pyx /path/to/espresso/src/python/espressomd/
```

Afterward, recompile ESPResSo making sure you have PyTorch linked in your Cmake toolchain:
```bash
cd /path/to/espresso/build
make -j4
```

### 3.2 Equilibration
Before starting the production simulation, it is essential to relax the system to remove any steric clashes (overlaps between atoms/beads) originating from the initial topology, especially when using hard repulsive potentials.

For equilibration, use the `equilibrate.py` script. The script performs a multi-phase procedure:
1. **Steepest Descent (Classical)**: Relaxation using only classical potentials (WCA and bonds).
2. **Langevin Warm-up (Classical)**: Classical dynamics with "force capping" to relax rotational degrees of freedom without blowing up the system.
3. **Steepest Descent (ML)**: Final relaxation including the neural network.
4. **Warm-up (ML)**: Brief dynamics with the active neural network and decreasing force capping.

```bash
python equilibrate.py \
    --model best_cg_model.pt \
    --config best_cg_model_config.json \
    --priors cg_priors.json \
    --rb_info rigid_bodies_info.json \
    --dataset cg_dataset.bin \
    --out_checkpoint equilibrated.npz \
    --dt 0.002 \
    --kT 2.49 \
    --steps_sd 5000 \
    --steps_md 2000 \
    --device auto
```
**Options supported by `equilibrate.py`:**
- `--model`, `--config`, `--priors`, `--rb_info`, `--dataset`: Required input files.
- `--out_checkpoint`: Output checkpoint file name (default: `equilibrated.npz`). Will contain the relaxed positions and velocities.
- `--dt`: Time-step for the MD phase (default: 0.002 ps).
- `--kT`: Temperature in kJ/mol (default: 2.49 for 300K).
- `--steps_sd`: Number of steps for Phase 1 Steepest Descent (default: 5000).
- `--steps_md`: Number of steps for Phase 2 Classical MD Warmup (default: 2000).
- `--device`: PyTorch device (`cpu`, `cuda`, `mps`, `auto`).

### 3.3 Running the Production Dynamics
The integration of ML + Priors is elegantly handled within the framework. The Neural Network (C++ Plugin) deals **exclusively** with the complex prediction. The Priors (WCA, Harmonic, FENE, Morse) are natively added inside ESPResSo's MD engine.

To simulate, use the `run_cg_md.py` script which will load the equilibrated coordinates from the checkpoint and start the production:

```bash
python run_cg_md.py \
    --model best_cg_model.pt \
    --config best_cg_model_config.json \
    --priors cg_priors.json \
    --rb_info rigid_bodies_info.json \
    --dataset cg_dataset.bin \
    --checkpoint equilibrated.npz \
    --steps 10000 \
    --dt 0.002 \
    --kT 2.49 \
    --device auto
```

**Options supported by `run_cg_md.py`:**
- `--model`, `--config`, `--priors`, `--rb_info`, `--dataset`: Required input files.
- `--checkpoint`: `.npz` file produced by `equilibrate.py` containing starting coordinates and velocities. If omitted, it will start from the dataset's frame 0 coordinates.
- `--steps`: Number of simulation steps (default: 10000).
- `--dt`: Time-step in picoseconds (default: 0.002 ps).
- `--kT`: Temperature in kJ/mol (default: 2.49).
- `--device`: PyTorch device.
- `--nve`: Runs the simulation in the NVE ensemble (no thermostat).
- `--apply_envelope`: Multiplies the forces predicted by the PaiNN network by a cosine function (envelope) at the cutoff radius to smoothly zero them out, solving NVE stability issues caused by linear Biases. (Optional: automatically loaded from the training JSON!)

> [!TIP]
> **NVE Stability and Neural Network Bias**
> By default, the framework trains models with `"use_bias": false` and `"apply_envelope": false`, guaranteeing $\mathcal{O}(dt^2)$ scaling natively. However, if you explicitly choose to train a model with biases (the "Thermodynamic Approach" for lower absolute errors), it is highly recommended to enable `"apply_envelope": true` in the training config. The simulation scripts (`equilibrate.py` and `run_cg_md.py`) will **automatically read** the `use_bias` and `apply_envelope` parameters from your `training_config.json`, ensuring absolute consistency between training and ESPResSo simulation. You no longer need to remember manual CLI flags!

### 3.4 Rigid Body Dynamics and Particle Filtering
In the framework, simulating multi-site molecules (Multi-Bead) leverages ESPResSo's **Virtual Sites**:
1. **The Real Particle (Center of Mass)**: For each rigid molecule, ESPResSo requires a single central particle endowed with mass and an inertia tensor. This is the only particle that the integrator physically moves in space.
2. **The Virtual Sites (The CG Beads)**: The interaction sites (e.g., `CH3`, `OH`) are instantiated as massless particles, whose position is rigidly anchored to the real particle. Any force applied to a virtual site is automatically translated by ESPResSo into a net force and **torque** on the real particle.

**The Neural Network Problem:**
The PaiNN neural network is trained *exclusively* on sites (e.g., types `0, 1, 2`). It knows nothing about a "Center of Mass". If we passed the Center of Mass to the ML Model, the latter would crash or produce random noise trying to interpret an unknown chemical species.

**The Solution (The `num_species` Filter):**
The C++ plugin (`PaiNN_ML_Potential.cpp`) includes an elegant filter: it accepts the `num_species` parameter (the total number of types known to the neural network). 
During the ESPResSo simulation:
- Virtual sites are assigned standard types (e.g., `0`, `1`, `2`). The Neural Network sees them, calculates distances, and predicts forces.
- The "Real" particle (the Center of Mass) is intentionally assigned a "ghost" type, which is an ID greater than or equal to `num_species` (e.g., `type = 100`).
- The C++ plugin **actively ignores** all particles with `type >= num_species`. 

The Center of Mass thus becomes "invisible" to Machine Learning, but remains perfectly active for ESPResSo's mechanics!
If you wish to make the Center of Mass particle interact:
- **Classically (e.g., WCA between molecules)**: Just define the interaction in ESPResSo for `type 100`.
- **With the Neural Network**: Simply include the Center of Mass as an explicit site in the `topology_config.json` during preprocessing, train the model including it (it will have its own `type` like `3`), and assign it that type in the simulation.

> [!NOTE]
> **"Real" vs "Virtual" Particles in ESPResSo**
> ESPResSo does not use the `type` to determine if a particle is Real or Virtual. The `type` is just a label for the Neural Network or Lennard-Jones parameters. The true nature of the particle is decided by the `virtual=True` or `virtual=False` flag during its creation in Python.
> 
> * Example: `system.part.add(pos=..., type=100, virtual=False)` creates the real particle. Newton will move it, but the neural network (stopping at types < 100) will ignore it.
> * Example: `system.part.add(pos=..., type=0, virtual=True)` creates a ghost site attached to the rigid body. The Neural Network will see it, apply force to it, and ESPResSo will leverage it, transferring force and torque to the real rigid body it is bound to.

### 3.5 Conservative Thermodynamic Capping and Ghost Management (C++ Plugin)
The native integration of ML into ESPResSo must deal with periodic boundaries and extremely high energy states. Our C++ plugin (`PaiNN_ML_Potential.cpp`) includes two fundamental physical mechanisms "under-the-hood" to maintain stability and energy conservation:

**1. Conservative Thermodynamic Capping (Soft-Clip)**
ML potentials can produce extreme gradients in the case of atomic overlaps ($r \to 0$), causing simulations to crash or explode in energy.
Traditional "force capping" (e.g., brutally truncating the force at 500 kJ/mol/nm) introduces non-conservative work: integrating a truncated force that is not the exact gradient of the potential breaks the Hamiltonian, causing the temperature to diverge in NVE/NVT ensembles.
To solve this, **in the plugin we apply a differentiable function (*softplus*) directly to the raw potential ENERGY**, creating a smooth horizontal asymptote for values $< -100$ and $> 500$ kJ/mol. In this way:
* When particles collide, the energy saturates smoothly and its derivative (the attractive/repulsive force of the network) goes towards zero.
* The force applied to the system remains *exactly* the analytical gradient of the capped energy ($F = -\nabla E_{capped}$).
* This preserves the thermodynamics of the system and the Hamiltonian conservation at 100%: the calculation falls back onto the classical WCA branches, preventing thermal and energy explosions.

**2. Authoritative Synchronization of ESPResSo "Ghosts"**
ESPResSo temporarily duplicates particles (called *ghosts*) to calculate interactions at the boundaries of the periodic simulation box. Often, attributes like the `mol_id` are not consistently synchronized on the ghosts.
To prevent the ML from calculating intra-molecular interactions (ignored by default) between a ghost and a real particle due to a mismatch in the molecular ID, the C++ plugin creates an **authoritative local map `id_to_mol_id`** at the beginning of the step, built only from real particles. During the construction of the spatial graph tensor, the molecular identities of the ghosts are strictly derived from this local map. This prevents catastrophic force spikes caused by erroneously evaluated bond distances across the box.

### 4. Energy Validation (Quadratic Scaling)
To ensure that the integration of PyTorch and the Priors within ESPResSo conserves energy (symplectic NVE simulation), you can use the dedicated test script:
```bash
cd simulation
/path/to/espresso/build/pypresso verify_energy_scaling.py
```
The script will iteratively reduce the time-step `dt` and calculate the standard deviation of the total energy ($E_{kin} + E_{bonded} + E_{ML}$). Since the integration algorithm is *Velocity Verlet*, the error must scale with $O(dt^2)$, which means that halving the time-step will reduce the fluctuation exactly by a factor of $\sim 0.25$!
